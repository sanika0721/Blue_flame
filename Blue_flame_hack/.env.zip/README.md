# BLUE FLAME · LPG Distribution ERP

A responsive React + TypeScript + Vite demo ERP for an LPG distributorship. It includes sample customers/bookings/payments, CRUD flows for customer, booking and payment entry, delivery confirmation with an IndexedDB outbox, inventory and deterministic reconciliation screens, CSV export, eight-language UI dictionaries, a read-only rule-based audit assistant, print-friendly reports, and an installable service-worker shell.

## Run locally

```sh
npm install
npm run dev
```

Open the Vite URL. The app starts in **demo mode** without credentials. Business records persist in this browser's local storage; offline delivery confirmations are stored in IndexedDB. Demo data are fictional. Reset them in Settings. This mode is intended for a hackathon walkthrough and is not a shared multi-user backend.

## Build

```sh
npm run build
npm run preview
```

## Supabase starter schema

1. Create a Supabase project and configure Auth users and tenant memberships.
2. Apply `supabase/migrations/202610280001_initial.sql` with the Supabase CLI.
3. Create a demo Auth user, then `supabase db reset` or load `supabase/seed.sql` in a development project.
4. Copy `.env.example` to `.env.local` and set the public Supabase URL and anon key.
5. Set production redirect URLs, disable public sign-up, create accounts through an admin process, and review RLS policies before onboarding real staff or customers.

The migration provides tenant-scoped tables, indexes, checks, role-aware RLS policies and append-only audit-log policies as a **backend starting point**. The current demo UI still uses local browser persistence; it does not yet authenticate against Supabase, call database RPCs, sync business data to Supabase, or enforce server-side booking and inventory transitions. Do not enter real customer, payment, subsidy, or staff data until those connections and policies have been reviewed and implemented.

## Demo behaviors and limits

- UI dictionaries are provided for English, Hindi, Telugu, Tamil, Kannada, Malayalam, Marathi, and Bengali. Missing keys fall back to English. Some sample rows and secondary explanatory copy remain English; the demo is not yet fully translated end to end.
- Booking creation and customer/payment forms persist locally. Duplicate mobile numbers are stopped for review. Delivery and payment remain separate. UPI entries are labelled simulated/unverified.
- Delivery outbox behavior uses IndexedDB. An online transition marks pending records as `synced-demo`; this acknowledges local demo handling only. There is no backend receiver, retry policy, conflict resolution service, or secure sign-out lifecycle yet.
- Dashboard charts, inventory counts, subsidy entries, dispute cases, staff and audit tables include clearly marked synthetic sample data. The demo reconciliation rules are illustrative; use the SQL schema and implement server-side rule evaluation before operational use.
- AI assistant answers use deterministic summaries from browser records. No LLM API, voice recognition, customer login/portal, WhatsApp delivery, notification service, role-enforced frontend module access, or production-grade auth is connected.
- `npm run build` checks types and creates the static deployable frontend bundle. Vercel can host the frontend, but configure Supabase and implement the missing data/auth integration before treating it as a production ERP.
